
require 'kadeploy3/kaadmin/install'

OPTIONS = {
  "install" => {
    :call => Kadeploy::Kaadmin::Install,
    :description => "install kernel or image on server",
  },
}
