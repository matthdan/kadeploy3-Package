require 'kadeploy3/common'
require 'kadeploy3/client/client'
